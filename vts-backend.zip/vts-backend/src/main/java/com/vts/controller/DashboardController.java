package com.vts.controller;

import com.vts.dto.DashboardResponse;
import com.vts.entity.Client;
import com.vts.entity.Driver;
import com.vts.entity.Vehicle;
import com.vts.model.VehiclePopupData;
import com.vts.service.AuthService;
import com.vts.service.DashboardService;
import com.vts.service.DriverService;
import com.vts.service.ThingsBoardDirectQueryService;
import com.vts.service.TripStateCache;
import com.vts.service.VehicleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;
    private final DriverService    driverService;
    private final VehicleService   vehicleService;
    private final TripStateCache   tripStateCache;
    private final AuthService      authService;
    private final ThingsBoardDirectQueryService thingsBoardDirectQueryService;

    public DashboardController(
            DashboardService dashboardService,
            DriverService driverService,
            VehicleService vehicleService,
            TripStateCache tripStateCache,
            AuthService authService,
            ThingsBoardDirectQueryService thingsBoardDirectQueryService
    ) {
        this.dashboardService = dashboardService;
        this.driverService    = driverService;
        this.vehicleService   = vehicleService;
        this.tripStateCache   = tripStateCache;
        this.authService      = authService;
        this.thingsBoardDirectQueryService = thingsBoardDirectQueryService;
    }

    @GetMapping("/summary")
    public ResponseEntity<DashboardResponse> getSummary() {
        return ResponseEntity.ok(dashboardService.getDashboardForCurrentClient());
    }

    @GetMapping("/drivers")
    public ResponseEntity<List<Driver>> listDriversForDashboard() {
        return ResponseEntity.ok(driverService.getAllDrivers());
    }

    @GetMapping("/vehicles")
    public ResponseEntity<List<Vehicle>> listVehiclesForDashboard() {
        return ResponseEntity.ok(vehicleService.getAllVehicles());
    }

    /**
     * Returns live vehicle positions for the dashboard map.
     * Shows ONLY vehicles with:
     * 1. Active trip (not Completed/Cancelled)
     * 2. LIVE telemetry from ThingsBoard (within 120 seconds)
     * Queries ThingsBoard directly instead of vehicle_tracking table.
     * Admin → all vehicles. Client → only their vehicles.
     */
    @GetMapping("/live-vehicles")
    public ResponseEntity<List<Map<String, Object>>> getLiveVehicles() {
        Client  client       = authService.getCurrentClient();
        boolean isSuperAdmin = authService.isSuperAdmin(client);
        boolean isOrgAdmin   = authService.isAdmin(client);
        Long    cid          = client != null ? client.getId() : null;
        Long    orgId        = client != null ? client.getOrgId() : null;

        // Pre-load vehicles currently deviating from live in-memory cache (fresh <=120s, active trip+route required)
        java.util.Set<String> deviatedVehicles = new java.util.HashSet<>();
        try {
            for (Map.Entry<String, TripStateCache.State> entry : tripStateCache.allEntries().entrySet()) {
                TripStateCache.State st = entry.getValue();
                if (st == null || st.lastPopup == null) continue;
                long ageSeconds = java.time.Duration.between(st.lastUpdateTime, java.time.Instant.now()).getSeconds();
                if (ageSeconds > 120) continue;
                if (!isSuperAdmin && !isOrgAdmin && cid != null && !cid.equals(st.clientId)) continue;
                if ("Yes".equalsIgnoreCase(st.lastPopup.getRouteDeviation())) {
                    deviatedVehicles.add(st.vehicleId);
                }
            }
        } catch (Exception ignored) {}
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            List<Map<String, Object>> telemetryData;
            if (isSuperAdmin) {
                telemetryData = thingsBoardDirectQueryService.fetchAllLiveTelemetry(null, null);
            } else if (isOrgAdmin) {
                telemetryData = thingsBoardDirectQueryService.fetchAllLiveTelemetry(null, orgId);
            } else {
                telemetryData = thingsBoardDirectQueryService.fetchAllLiveTelemetry(cid, null);
            }
            for (Map<String, Object> row : telemetryData) {
                String vid = (String) row.get("vehicle_id");
                if (vid == null || row.get("lat") == null || row.get("lng") == null) continue;
                double lat = ((Number) row.get("lat")).doubleValue();
                double lng = ((Number) row.get("lng")).doubleValue();
                double spd = row.get("speed") != null ? ((Number) row.get("speed")).doubleValue() : 0;

                VehiclePopupData popup = new VehiclePopupData();
                popup.setVehicleId(vid);
                popup.setStatus(row.get("trip_status") != null ? row.get("trip_status").toString() : "Idle");
                popup.setDriverName(row.get("driver_name") != null ? row.get("driver_name").toString() : "");
                popup.setSpeed(String.valueOf((int) spd));
                popup.setLat(lat);
                popup.setLng(lng);
                popup.setOverspeed(row.get("overspeed")          != null ? row.get("overspeed").toString()          : "No");
                popup.setSmoking(row.get("smoking_status")       != null ? row.get("smoking_status").toString()     : "No");
                popup.setMobileUsage(row.get("mobile_usage")     != null ? row.get("mobile_usage").toString()       : "No");
                popup.setDrowsiness(row.get("drowsiness_status") != null ? row.get("drowsiness_status").toString()  : "Normal");
                popup.setHarshBraking(row.get("harsh_braking")   != null ? row.get("harsh_braking").toString()      : "No");
                popup.setHarshAcceleration(row.get("harsh_acceleration") != null ? row.get("harsh_acceleration").toString() : "No");
                popup.setRashTurning(row.get("rash_turning")     != null ? row.get("rash_turning").toString()        : "No");
                popup.setRouteDeviation(deviatedVehicles.contains(vid) ? "Yes" : "No");
                popup.setAddress(row.get("address")        != null ? row.get("address").toString()        : "");
                popup.setCoordinates(row.get("coordinates") != null ? row.get("coordinates").toString()  : "");
                popup.setLastUpdateTime(row.get("lastUpdateTime") != null ? row.get("lastUpdateTime").toString() : "");
                popup.setLastUpdateDate(row.get("lastUpdateDate") != null ? row.get("lastUpdateDate").toString() : "");
                result.add(buildVehicleEntry(vid, lat, lng, spd, popup.getDriverName(), popup));
            }
        } catch (Exception ignored) {}
        return ResponseEntity.ok(result);
    }

    private Map<String, Object> buildVehicleEntry(String vehicleId, double lat, double lng,
                                                   double speed, String driverName, VehiclePopupData popup) {
        java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("vehicleId",   vehicleId);
        m.put("lat",         lat);
        m.put("lng",         lng);
        m.put("speed",       speed);
        m.put("driverName",  driverName);
        if (popup != null) {
            m.put("tripStatus",      popup.getStatus());
            m.put("overspeed",       popup.getOverspeed());
            m.put("smoking",         popup.getSmoking());
            m.put("mobileUsage",     popup.getMobileUsage());
            m.put("drowsiness",      popup.getDrowsiness());
            m.put("harshBraking",    popup.getHarshBraking());
            m.put("harshAcceleration", popup.getHarshAcceleration());
            m.put("rashTurning",     popup.getRashTurning());
            m.put("routeDeviation",  popup.getRouteDeviation());
            m.put("address",         popup.getAddress());
            m.put("coordinates",     popup.getCoordinates());
            m.put("lastUpdateTime",  popup.getLastUpdateTime());
            m.put("lastUpdateDate",  popup.getLastUpdateDate());
        }
        return m;
    }
}
